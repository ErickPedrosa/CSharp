﻿
namespace Aula09
{
    public class Program
    {
        public static void Main(string[] args)
        {
            //TestaArea.Teste();
            
            TestaTributavel.Teste();

        }




    }


}