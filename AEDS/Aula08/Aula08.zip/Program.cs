﻿using Aula08;
using System;


namespace Aula08
{
    public class Program
    {
        public static void Main(string[] args)
        {

            //TestaBanco.MainBanco();
            TestaAgenda.TesteAgenda();
        }
    }
}
